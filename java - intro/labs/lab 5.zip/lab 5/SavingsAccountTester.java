/**
 * Tests the SavingsAccount object
 * 
 * Last test: 11/5/07
 */
public class SavingsAccountTester
{
     /**
      * @param args String arguments for the main method
      */
     public static void main (String args [])
     {
          
          SavingsAccount mySavingsAccount = new SavingsAccount (1000);
          

          mySavingsAccount.withdraw (0);
          mySavingsAccount.deposit (0);
          mySavingsAccount.addInterest (10);
          mySavingsAccount.addInterest (10);
          mySavingsAccount.addInterest (10);
          mySavingsAccount.addInterest (10);
          mySavingsAccount.addInterest (10);
          
          System.out.println ("My savings account has $"+ mySavingsAccount.checkBalance ());
          
     }// end main method
}// end SavingsAccount class