/* Ryan O'Hara
 * September 20, 2007
 * 8th Period
 * Last modified 9/19/20007
 * This program will display my intials 
 */
public class Myinitials  
{
     public static void main (String [] args)
     {
          // Display a greeting in the console window
     
          System.out.println ("RRRRR      OOO");
          System.out.println ("R    R    O   O");
          System.out.println ("R   R    O     O");
          System.out.println ("RRRR     O     O");
          System.out.println ("R   R     O   O");
          System.out.println ("R    R     OOO");  
     }//end of main method 
}//end of the class 