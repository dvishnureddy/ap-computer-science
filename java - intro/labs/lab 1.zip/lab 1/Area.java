/* Ryan O'Hara
 * September 20, 2007
 * 8th Period
 * Last modified 9/19/20007
 * This program will give the area of two numbers
 */ 
public class Area
{
     public static void main (String [] args) 
     { double length = 10;
       double width = 5;
       double area = length * width; 
       //display a gretting in the console window   
       System.out.println ("The area of a rectangle with "+ width +" width and "+ length +" length is "+ area);
       
     }//end of main method
}//end of class