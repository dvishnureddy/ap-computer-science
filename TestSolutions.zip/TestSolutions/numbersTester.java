/*Ryan O'Hara
 * Tests numbers.java
 * 10-27-08
 */
public class numbersTester
{
     public static void main(String[] args)
     {
       numbers n = new numbers ();
       
       System.out.println ("The sum of the multiples of three are: " + n.mult3Sum(1, 20));
     }
}
         