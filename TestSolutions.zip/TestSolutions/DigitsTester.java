/*Ryan O'Hara
 * Tests Digits.java
 * 10-27-08
 */
public class DigitsTester
{
     public static void main(String[] args)
     {
       Digits d = new Digits ();
       
       System.out.println (d.numberOfSevens(970275737667.0));
     }
}