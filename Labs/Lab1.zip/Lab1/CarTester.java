/**
 * Tests the Car object
 * Ryan O'Hara
 * September 24, 2008
 */
public class CarTester
{
     
     public static void main (String args [])
     {
          
          Car myCar = new Car (25);
          Car myHummer = new Car (15);

          myCar.addGas (10);
          myHummer.addGas (20);
          myCar.drive (100);
          myHummer.drive (225);
          
          System.out.println ("My Car has "+ myCar.checkGas ()+" gallons of gas remaining");
          System.out.println ("\nMy Hummer has "+ myHummer.checkGas () +" gallons of gas remaining");
          
     }// end main method
}// end Car class