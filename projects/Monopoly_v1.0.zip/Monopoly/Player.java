 /**
  * A Player for Monopoly
  * @author Ryan O'Hara
  * @version 1.0
 */
public class Player
{
     String player1 = new String ("");
     String whichPiece = new String ("");
     int space, doubles;
     double money;
     boolean inJail;
     
     /**
      * Creates the player
      * @param name The name of the Player
      * @param piece The player's game piece
      */
     public Player (String name, String piece)
     {
          player1 = name;
          space = 0;
          money = 1500.0;
          doubles = 0;
          whichPiece = piece;
          inJail = false;
     }
     
     /**
      * Gets the Player's name
      * @return The name of the player
      */
     public String getName ()
     {
          return player1;
     }
     
     /**
      * Sets the space of the Player
      * @param location The Player's space
      */
     public void setSpace (int location)
     {
          space = location;
     }
     
     /**
      * Gets the Player's space
      * @return The Player's space
      */
     public int getSpace ()
     { 
          return space;
     }
     
     /**
      * Moves the Player's piece
      * @param amount The amount of spaces to move the Player's piece
      */
     public void movePiece (int amount)
     {
          space += amount;
     }
     
     /**
      * Gets the Player's piece
      * @return The game piece for the Player
      */
     public String getPiece ()
     {
          return whichPiece;
     }
     
     /**
      * Adds the number of doubles the Player has rolled
      */
     public void addDoubles ()
     {
          doubles++;
     }
     
     /**
      * Gets the number of doubles the Player has rolled
      * @return The number of doubles
      */
     public int getDoubles ()
     {
          return doubles;
     }
     
     /**
      * Resets the number of doubles the Player has rolled
      */
     public void resetDoubles ()
     {
          doubles = 0;
     }
     
     /**
      * Sets if the Player is in jail or not
      * @param j Whether the Player is in or out of jail
      */
     public void setInJail (boolean j)
     {
          inJail = j;
     }
     
     /**
      * Returns whether or not the player is in jail
      * @return If the Player is in jail or not
      */
     public boolean isInJail ()
     {
          return inJail;
     }
     
     /**
      * Sets the money for the Player
      * @param cash The amount of money the player gains or loses
      */
     public void setMoney (double cash)
     {
          money += cash;
     }
     
     /**
      * Gets the amount of money the Player has
      * @return The amount of money the Player has
      */
     public double getMoney ()
     {
          return money;
     }
     
     /**
      * Gives money to the player for passing go
      */
     public void passGo ()
     {
       money += 200.0;
     }
     
     /**
      * Gets all the info of the Player
      * @return The Player's info
      */
     public String toString ()
     {
          return new String ("Name: "+ player1 +"\nPiece: "+ whichPiece +"\nSpace: "+ space +"\nMoney: "+ money); 
     }
}
          
          
     