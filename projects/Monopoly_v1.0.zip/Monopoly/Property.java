 /**
  * Property for Monopoly
  * @author Ryan O'Hara
  * @version 1.0
 */

public class Property
{
     private String name;
     private int owner;
     private int type;
     private String color;
     private int cost;
     private int rent;
     private int morgage;
     private int space; 
     
     /**
      * sets the initial values for the property
      * @param n The name of the property
      * @param o The name of the owner
      * @param t The type of property
      * @param col The color of the property
      * @param cos The cost of the property
      * @param r The rent for the property
      * @param m The morgage for the property
      * @param s The space the property is on
      */
     public Property (String n, int o, int t, String col, int cos, int r, int m, int s)
     {
          name = n;
          owner = o;
          type = t;
          color = col;
          cost = cos;
          rent = r;
          morgage = m;
          space = s;
     }
     
     /**
      * Gets the name of the property
      * @retrun name The name
      */
     public String getName()
     {
          return name;
     }
     
     /**
      * Gets the owner of the property
      * @rturn The owner
      */
     public int getOwner()
     {
          return owner;
     }
     
     /**
      * Sets the owner of the property
      * @param manager The owner
      */
     public void setOwner(int manager)
     {
          owner = manager;
     }
     
     /**
      * Gets the type of property
      * @return The type
      */
     public int getType() 
     {
          return type;
     }
     
     /** 
      * Gets the color of the property
      * @return The color
      */
     public String getColor()
     {
          return color;
     }
     
     /**
      * Gets the cost of the property
      * @return The cost
      */
     public int getCost()
     {
          return cost;
     }
     
     /**
      * Gets the rent for the property
      * @return The rent
      */
     public int getRent()
     {
          return rent;
     }
     
     /**
      * Gets the morgage of the property
      * @return The morgage
      */
     public int getMorgage()
     {
          return morgage;
     }
     
     /*
      * Gets the Space the property is on
      * @return The space
      */
     public int getSpace()
     {
          return space;
     }
     
     /**
      * Gets all the info for the property
      * @return the info
      */
     public String toString()
     {
          return new String ("name: " + name + "\nowner: " + owner + "\ntype: " + type + "\ncolor: " + color + "\ncost: " + cost + "\nrent: " + rent + "\nspace: " + space);
     }
     
}
     
     