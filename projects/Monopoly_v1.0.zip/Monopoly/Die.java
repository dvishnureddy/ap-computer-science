 /**
  * Rolls a Die for Monopoly
  * @author Ryan O'Hara
  * @version 1.0
 */
import java.util.Random;

public class Die
{
     private Random gen;
     private int numSides;
     /**
      * Creates a die
      * @param sides The number of sides
      */
     public Die (int sides)
     {
          numSides = sides;
          gen = new Random();
     }
     
     /**
      * Gets the number of sides for a Die
      * @return The number of sides
      */
     public int getNumSides ()
     {
          return numSides;
     }
     
     /**
      * sets the number of sides for a Die
      * @param newSides The new number of sides for a Die
      */
     public void setNumSides (int newSides)
     {
          numSides = newSides;
     }
     
     /**
      * gets the roll of the die
      * @return The roll of the Die
      */
     public int getRoll()
     {
          return gen.nextInt (numSides) +1;
     }    
}