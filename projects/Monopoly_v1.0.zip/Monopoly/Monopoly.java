/**
 * Play Monopoly using Player and Die
 * @author Ryan O'Hara
 * @version 1.0
 */
import java.util.Scanner;
import javax.swing.*;

public class Monopoly
{
  /**
   * Sets up the Monopoly game
   * @param args Do not know what this does
   */
  public static void main (String args [])
  {
    Scanner in = new Scanner (System.in);
    
    
    Die d1 = new Die (6);
    
    boolean gameOver = false;
    
    while (gameOver == false)
    {
      System.out.println ("Welcome to MONOPOLY!");
      System.out.println (" ==============="
                            + "\n[M|O|N|O|P|O|L|Y]");
      
      System.out.println ("\nPlayer 1 enter your name: ");
      String name = in.nextLine ();
      System.out.println ("\nThere are 9 pieces: Thimble, Bag of Money, Cannon, Top Hat, Boot, Dog, Car, Iron and Wheelbarrow");
      System.out.println ("Player 1 enter your piece: ");
      String piece = in.nextLine ();
      
      Player p1 = new Player (name, piece);
      
      int menu = 0;
      do
      {
        if (p1.isInJail() == false)
        {
          System.out.println (p1.toString());
          System.out.println ("\nEnter 1 to roll or 2 to quit: ");
          menu = in.nextInt ();
          
          if (menu == 1)
            takeTurn(d1, p1);
          
          else if (menu == 2)
          {
            System.out.println ("Quitting game");
            gameOver = true;
            break;
          }
          else
            System.out.println ("You did not type the right choice");
        }
        else
          Jail (d1, p1);
      }
      while (menu != 2);
    }
  }
  
  /**
   * Rolls the die so the Plyer can move around the board
   * @param d1 The die
   * @param p1 The Player
   */
  public static void takeTurn (Die d1, Player p1)
  {
    boolean arrested = false;
    boolean roll = true;
    
    while (roll)
    {
      int roll1 = d1.getRoll ();
      int roll2 = d1.getRoll ();
      int rollSum = roll1 + roll2;
      
      if (roll1 == roll2)
      {
        System.out.println ("You rolled double "+ (rollSum/2)+"'s");
        p1.addDoubles ();
        int dRoll1 = d1.getRoll ();
        int dRoll2 = d1.getRoll ();
        int doubleSum = dRoll1 + dRoll2;
        int totalSum = doubleSum + rollSum;
        
        System.out.println("Your second roll was a "+ doubleSum +" in total you rolled a "+ totalSum);
        p1.movePiece (totalSum);
        System.out.println ("The "+ p1.getPiece() + " landed on space "+ p1.getSpace()+"\n");
        
        if (p1.getSpace() >= 40)
        {
          p1.setSpace(p1.getSpace() - 40);
          p1.passGo();
          System.out.println ("The "+ p1.getPiece() +" passed go and now has $"+p1.getMoney ());
        }
        
        roll = false;
      }
      
      while (roll && p1.isInJail() == false)
      {
        roll = false;
        p1.movePiece(rollSum);
        if (p1.getSpace() >= 40)
        {
          p1.setSpace(p1.getSpace() - 40);
          p1.passGo();
          System.out.println ("The "+ p1.getPiece() +" passed go and now has $"+p1.getMoney ());
        }
        
        System.out.println ("\nYour roll was a "+rollSum);
        System.out.println ("The "+ p1.getPiece() + " landed on space "+ p1.getSpace()+"\n");
        
        if (p1.getSpace() == 30)
        {
          System.out.println ("You go to jail and do not collect money for pass and go");
          p1.setSpace (10);
          Jail (d1, p1);
        }
      
      if (p1.getDoubles() == 3)
      {
        p1.setSpace (10);
        Jail(d1, p1);
        arrested = true;
        roll = false;
        p1.setInJail (arrested);
      }
      else
      {
        p1.resetDoubles ();
      }
    }
    }
  }//end takeTurn
  /**
   * Ways for the Player to get out of Jail
   * @param d1 The die
   * @param p1 The Player
   */
  public static void Jail (Die d1, Player p1)
  {
    Scanner in = new Scanner (System.in);
    p1.resetDoubles ();
    
    boolean arrested = true;
    
    while (arrested)
    {
      System.out.println ("Type 1 to roll and 2 to pay the $50 fine");
      int choice = in.nextInt ();
      
      switch (choice)
      {
        case 1:
          p1.setSpace (10);
          p1.resetDoubles ();
          int jailRoll = 0;
          int jailRoll1 = d1.getRoll ();
          int jailRoll2 = d1.getRoll ();
          int jailSum = jailRoll1 + jailRoll2;
          boolean jRoll = true;
          
          if (jRoll && jailRoll < 3)
          {
            
            if (jailRoll1 == jailRoll2)
            {
              System.out.println ("You rolled double "+ (jailSum/2) +"'s");
              p1.addDoubles ();
              p1.movePiece (jailSum);
              System.out.println ("The "+ p1.getPiece() + " landed on space "+ p1.getSpace()+"\n");
              arrested = false;
              p1.setInJail (arrested);
              jRoll = false;
            }
            else
            {
              jailRoll ++;
              System.out.println ("You did not roll doubles");
              jRoll = false;
            }
          }
          else
          {
            System.out.println ("You had three chances to roll doubles now you have to pay the fine to get out.");
            p1.setMoney (-50);
            System.out.println ("Thanks for paying the fine the "+ p1.getPiece() +" now has $"+p1.getMoney ());
            arrested = false;
            p1.setInJail (arrested);
          }
          break;
        
        case 2:
          p1.setMoney (-50);
          arrested = false;
          p1.setInJail (arrested);
          System.out.println ("Thanks for paying the fine the "+ p1.getPiece() +" now has $"+p1.getMoney ());
          break;
        
      }
    }
  }//end Jail
}
